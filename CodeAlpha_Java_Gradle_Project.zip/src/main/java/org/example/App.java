package org.example;

public class App { 
    public static void main(String[] args) {
        System.out.println("Hello CodeAlpha DevOps Internship!");
        System.out.println("Java Application using Gradle");
     }
}
